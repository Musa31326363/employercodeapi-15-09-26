function generateSetID(userId) {
  if (!userId) {
    throw new Error("USERID is required to generate SET_ID");
  }

  const now = new Date();

  const day = String(now.getDate()).padStart(2, "0");
  const month = now.toLocaleString("en-US", { month: "short" }).toUpperCase();
  const year = String(now.getFullYear()).slice(-2);
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `${userId}${day}${month}${year}${hours}${minutes}${seconds}`;
}

module.exports = generateSetID;
