const validateEmployerRequest = (req, res, next) => {
  const requiredFields = [
    "registrationCode",
    "employerType",
    "name",
    "address",
    "sectorCode",
    "natureOfBusiness",
    "taxId",
    "email",
    "requestId",
    "requestDate",
    "status",
    "supportingDocument"
  ];

  // Only require pfaCode when the user is NOT an employer
  const EMPLOYER_ROLE_ID = 'EMPLOYER';

  if (req.user?.roleId !== EMPLOYER_ROLE_ID) {
    requiredFields.push("pfaCode");
  }

  const body = req.body || {};

  const missingFields = [];
  const emptyFields = [];

  requiredFields.forEach((field) => {
    if (!(field in body)) {
      missingFields.push(field);
      return;
    }

    const value = body[field];

    if (
      value === null ||
      value === undefined ||
      (typeof value === "string" && value.trim() === "")
    ) {
      emptyFields.push(field);
    }
  });

  if (missingFields.length > 0 || emptyFields.length > 0) {
    return res.status(400).json({
      message: "Validation failed",
      missingFields,
      emptyFields
    });
  }

  next();
};

module.exports = validateEmployerRequest;