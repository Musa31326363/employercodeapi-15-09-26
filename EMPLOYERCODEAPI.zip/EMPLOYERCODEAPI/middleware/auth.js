const { getConnection } = require("../db/oracle");

const authenticateUser = async (req, res, next) => {
  let connection;

  try {
    const username = req.headers["username"];
    const password = req.headers["password"];

    if (!username || !password) {
      return res.status(401).json({
        message: "Authentication failed",
        error: "Username and password must be provided in headers"
      });
    }

    connection = await getConnection();

    const sql = `
      SELECT USER_ID, ROLE_ID
      FROM TBL_USER_ROLES
      WHERE USER_ID = :username
      AND USER_PASSWORD = :password
    `;

    const result = await connection.execute(sql, {
      username,
      password
    });

    if (!result.rows || result.rows.length === 0) {
      return res.status(401).json({
        message: "Authentication failed",
        error: "Invalid username or password"
      });
    }

    // Works when oracledb is configured with OUT_FORMAT_OBJECT
    const row = result.rows[0];

    const userId = row.USER_ID;
    const roleId = row.ROLE_ID;

    req.user = {
      userId,
      roleId
    };

    next();

  } catch (error) {
    console.error("Authentication error:", error);

    res.status(500).json({
      message: "Authentication error",
      error: error.message
    });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Connection close error:", err);
      }
    }
  }
};

module.exports = authenticateUser;

