// Model/userQuery.js

const oracledb = require('oracledb');
//const { oracledb } = require('../db/oracle');

const getUserDetails = async (username, password, connection) => {
  const query = `
    SELECT USER_ID, USER_PASSWORD
    FROM TBL_USER_ROLES
    WHERE USER_ID = :username AND USER_PASSWORD = :password
  `;

  return await connection.execute(
    query,
    { username, password },
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
};

const verifyUser = async (username, connection) => {
  const query = `
    SELECT USER_PASSWORD, PASSWORD_STATUS
    FROM TBL_USER_ROLES
    WHERE USER_ID = :username
  `;

  return await connection.execute(
    query,
    { username },
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
};

const updateUserPassword = async (username, hashedPassword, connection) => {
  const query = `
    UPDATE TBL_USER_ROLES
    SET USER_PASSWORD = :newPassword
    WHERE USER_ID = :username
  `;

  return await connection.execute(
    query,
    { newPassword: hashedPassword, username },
    { autoCommit: true }
  );
};

const updateFirstLoginStatus = async (username, connection) => {
  const query = `
    UPDATE TBL_USER_ROLES
    SET PASSWORD_STATUS = 'N'
    WHERE USER_ID = :username
  `;

  return await connection.execute(
    query,
    { username },
    { autoCommit: true }
  );
};


module.exports = {
  getUserDetails,
  verifyUser,
  updateUserPassword,
  updateFirstLoginStatus
};
