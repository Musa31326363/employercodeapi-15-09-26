const express = require("express");
const router = express.Router();
const oracledb = require("oracledb");

const { getConnection } = require("../db/oracle");
const validateEmployerRequest = require("../middleware/validation");
const authenticateUser = require("../middleware/auth");
const generateSetID = require("../middleware/generateSetID");

/**
 * Validate Base64
 */
function isValidBase64(base64) {
  if (!base64 || typeof base64 !== "string") {
    return false;
  }

  const cleaned = base64.replace(/^data:.*;base64,/, "");

  return (
    cleaned.length % 4 === 0 &&
    /^[A-Za-z0-9+/]+={0,2}$/.test(cleaned)
  );
}

/**
 * Get Employer Code Status
 */
router.post(
  "/get-empco-status",
  authenticateUser,
  async (req, res) => {
    let connection;

    try {
      const { setId } = req.body;

      if (!setId) {
        return res.status(400).json({
          message: "SET_ID is required"
        });
      }

      connection = await getConnection();

      const result = await connection.execute(
        `
        SELECT STATUS
        FROM TBL_EMPLOYER_CODE_REQ
        WHERE SET_ID = :setId
        `,
        { setId },
        {
          outFormat: oracledb.OUT_FORMAT_OBJECT
        }
      );

      if (result.rows.length === 0) {
        return res.status(404).json({
          message: "No request found for the provided SET_ID"
        });
      }

      return res.status(200).json({
        setId,
        status: result.rows[0].STATUS
      });
    } catch (error) {
      console.error(error);

      return res.status(500).json({
        message: "Failed to retrieve status",
        error: error.message
      });
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  }
);

/**
 * Create Employer Code Request
 */
router.post(
  "/employer-code-request",
  authenticateUser,
  validateEmployerRequest,
  async (req, res) => {
    let connection;

    try {
      const {
        registrationCode,
        employerType,
        name,
        address,
        sectorCode,
        natureOfBusiness,
        taxId,
        email,
        pfaCode,
        requestDate,
        supportingDocument
      } = req.body;

      // Get authenticated user's ID and role
      const { userId, roleId } = req.user;

      /**
       * Automatically assign PFA_CODE = "001"
       * when the authenticated user is an EMPLOYER.
       *
       * For all other roles, use the PFA code
       * supplied in the request body.
       */
      const finalPfaCode =
        roleId === "EMPLOYER" ? "001" : pfaCode;

      // PFA_CODE is required for roles other than EMPLOYER
      if (roleId !== "EMPLOYER" && !finalPfaCode) {
        return res.status(400).json({
          field: "pfaCode",
          message: "pfaCode is required for this user role"
        });
      }

      // Always use Manual status
      const status = "Manual";

      // Validate supporting document
      if (!isValidBase64(supportingDocument)) {
        return res.status(400).json({
          field: "supportingDocument",
          message:
            "supportingDocument must be a valid Base64 encoded document"
        });
      }

      // Remove Base64 data URI prefix if present
      const cleanedBase64 = supportingDocument.replace(
        /^data:.*;base64,/,
        ""
      );

      // Convert Base64 to Buffer
      const documentBuffer = Buffer.from(
        cleanedBase64,
        "base64"
      );

      // Maximum document size: 5MB
      const maxSize = 5 * 1024 * 1024;

      if (documentBuffer.length > maxSize) {
        return res.status(400).json({
          field: "supportingDocument",
          message: "Document size must not exceed 5MB"
        });
      }

      // Generate SET_ID
      const setId = generateSetID(userId);

      // Get Oracle connection
      connection = await getConnection();

      // Insert employer code request
      await connection.execute(
        `
        INSERT INTO TBL_EMPLOYER_CODE_REQ (
          REG_NO,
          EMPLOYER_TYPE,
          NAME,
          ADDRESS,
          SECTOR_CODE,
          NATURE_OF_BUSINESS,
          TIN,
          EMAIL,
          SET_ID,
          PFA_CODE,
          REQUEST_DATE,
          STATUS,
          SUPPORT_DOC_BLOB
        ) VALUES (
          :registrationCode,
          :employerType,
          :name,
          :address,
          :sectorCode,
          :natureOfBusiness,
          :taxId,
          :email,
          :setId,
          :pfaCode,
          :requestDate,
          :status,
          :supportDocBlob
        )
        `,
        {
          registrationCode,
          employerType,
          name,
          address,
          sectorCode,
          natureOfBusiness,
          taxId,
          email,
          setId,

          // EMPLOYER users always save "001"
          pfaCode: finalPfaCode || null,

          requestDate: new Date(requestDate),
          status,
          supportDocBlob: documentBuffer
        },
        {
          autoCommit: true
        }
      );

      // Return success response
      return res.status(201).json({
        message: "Employer code request saved successfully",
        setId,
        status,
        pfaCode: finalPfaCode || null
      });
    } catch (error) {
      console.error(error);

      return res.status(500).json({
        message: "Failed to save employer code request",
        error: error.message
      });
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  }
);

module.exports = router;