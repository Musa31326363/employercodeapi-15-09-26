// routes/resetPassword.js
const express = require('express');
const bcrypt = require('bcryptjs');
const { getConnection } = require('../db/oracle');
const {
  verifyUser,
  updateUserPassword,
  updateFirstLoginStatus
} = require('../Model/userQuery');

const router = express.Router();

const resetPasswordMiddleware = async (req, res, next) => {
  const userid = req.headers['userid'];
  const oldPassword = req.headers['oldpassword'];
  const newPassword = req.headers['newpassword'];

  if (!userid || !oldPassword || !newPassword) {
    return res.status(400).json({ message: 'userid, old password, and new password are required.' });
  }

  req.userid = userid;
  req.oldPassword = oldPassword;
  req.newPassword = newPassword;

  next();
};

router.post('/passwordreset', resetPasswordMiddleware, async (req, res) => {
  const { userid, oldPassword, newPassword } = req;
  let connection;

  try {
    connection = await getConnection();

    const result = await verifyUser(userid, connection);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Username not found.' });
    }

    const user = result.rows[0];

    if (user.PASSWORD_STATUS !== 'Y') {
      return res.status(403).json({ message: 'Password reset not allowed. Not first login. Contact PENCOM.' });
    }

    if (oldPassword !== user.USER_PASSWORD) {
      return res.status(401).json({ message: 'Invalid old password.' });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    const updateResult = await updateUserPassword(userid, hashedNewPassword, connection);

    if (updateResult.rowsAffected > 0) {
      await updateFirstLoginStatus(userid, connection);

      return res.status(200).json({
        message: 'Password updated successfully.',
        hashedPassword: hashedNewPassword
      });
    } else {
      return res.status(400).json({ message: 'Failed to update the password. Please try again.' });
    }
  } catch (err) {
    console.error('Error during password reset:', err);
    return res.status(500).json({ message: 'Internal server error.' });
  } finally {
    if (connection) {
      await connection.close();
    }
  }
});

module.exports = router;
